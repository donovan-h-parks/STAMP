Costello whole body sites data was obtained from:
http://www.microbio.me/qiime/

Taxonomic attributions (Costello.rdp.taxonomy) and group information (Costello.groups) were obtained with mothur:
http://www.mothur.org/

The metadata file (Costello.metadata.tsv) was created by hand based on data from:
Bacterial Community Variation in Human Body Habitats Across Space and Time
  by Elizabeth K. Costello et al., Science (2009)
  http://www.sciencemag.org/content/326/5960/1694.short
 
This data can be converted to a STAMP profile using:
File->Create STAMP profile from...->mothur data